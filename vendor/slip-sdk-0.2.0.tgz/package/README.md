# @slip/sdk

Infrastructure SDK for AI-compiled, TxLINE-settled parimutuel markets on Solana.

## Public boundaries

- The default `@slip/sdk` entry is browser safe and Kit based.
- `SlipClient.compileRulebook` calls a configured real Slip server API and preserves consumer labels exactly.
- `@slip/sdk/ai` uses AI SDK structured output to interpret natural language on a server.
- `@slip/sdk/txline` owns authenticated TxLINE fixtures, snapshots, and proofs.
- `createOllamaRuleModel` runs the same compiler against a local or LAN-hosted Ollama model.
- `compileMarketRuleOutput` maps semantic output to canonical TxLINE keys and rejects invalid partitions.
- `RULEBOOK_PROMPT_SKILLS` and `RULEBOOK_PROMPT_EXAMPLES` assemble reusable domain guidance and few-shot demonstrations.
- `TxlineClient` owns guest JWT renewal, fixture and score snapshots, proof retrieval, and token activation.
- The public `SlipClient` builds all five generated Kit instructions, verifies references, reads accounts, and closes browser subscriptions.
- `./generated` exports the checked-in Codama client rendered from the Anchor IDL.

The default package installs only `@solana/kit`. Server and legacy entry points declare their
runtime libraries as optional peers, so a browser or automated reader does not inherit Anchor,
web3.js, SPL Token, AI providers, or Ollama merely by installing the SDK. Consumers of `/ai`,
`/txline`, or `/legacy` install the optional peers used by that entry point explicitly.

The model never supplies fixture IDs, stat keys, fees, stakes, or settlement values. Model output is
untrusted until the deterministic validator accepts it.

## Compile a Rulebook

```ts
import { compileMarketRule } from "@slip/sdk/ai";
import { TxlineClient } from "@slip/sdk/txline";

const txline = new TxlineClient({
  origin: process.env.TXLINE_DEVNET_ORIGIN,
  apiToken: process.env.TXLINE_API_TOKEN,
});
const fixture = await txline.getFixture(18_209_181);
const rule = await compileMarketRule({
  model: process.env.SLIP_RULE_MODEL!,
  fixture,
  text: "Will both teams score before halftime?",
});
```

AI Gateway credentials belong on a server. Browser applications should call a server route such as
Slip's `POST /api/v1/compile` rather than embed provider credentials.

## Build a public-client action

```ts
import { address } from "@solana/kit";
import { createSlipClient, parseAmount } from "@slip/sdk";

const client = createSlipClient({
  network: "devnet",
  rpcUrl: process.env.SOLANA_RPC_DEVNET!,
  websocketUrl: process.env.SOLANA_WS_DEVNET,
  programAddress: address(process.env.SLIP_PROGRAM_ID!),
  settlementMint: address(process.env.SLIP_SETTLEMENT_MINT!),
});
if (!(await client.supportsUnifiedMarkets())) throw new Error("Unified Slip binary unavailable");

const prepared = await client.buyTicket({
  market: address(marketAddress),
  buyer: address(walletAddress),
  outcomeIndex: 2,
  amount: parseAmount("3.5"),
  nonce: 1n,
});
```

The returned Kit instructions are real and include required idempotent ATA creation. The application
retains signing, simulation, submission, and confirmation authority through Wallet Standard or its
server signer; the public SDK never invents a successful transaction.

## Reads and subscriptions

- `getMarket`, `getTicket`, `listMarkets`, `listWalletTickets`
- `watchMarket` with an explicit teardown function
- `verifyReference`, `marketAddress`, `ticketAddress`

Core Solana RPC has no server-side `getProgramAccounts` pagination. SDK cursor pages are deterministic
but perform one program-account scan. Operators with large account sets should back the same public
contract with a real Geyser or RPC indexer; the SDK does not pretend local slicing is provider-side pagination.

## Verification

```bash
pnpm --filter @slip/sdk test
pnpm --filter @slip/sdk typecheck
pnpm --filter @slip/sdk build
pnpm --filter @slip/program test:surfpool
```

Live boundaries are explicit commands because they require credentials:

```bash
pnpm --filter @slip/sdk test:ai
pnpm --filter @slip/sdk test:txline
```
